%% START MATLAB
format compact
format short
clc, clear, close all

tic
%% COMPILE C-FILE
mex fast_sim_laser_SYS1.c
DIM = 4; bif_eqn = 2;

% mex fast_sim_laser_SYS3.c
% DIM = 7; Bif_num = 3;

% mex fast_sim_laser_SYS4.c
% DIM = 5; Bif_num = 1;

mex fast_detect_extrema.c

%% INITIALISE PARAMETERS
% System Parameters
eta     = 0;                          % sweep [0, 0.06]
omega   = 0;
alpha   = 3;                          % 2, in [2, 3, 5]
ka      = 0.96;                       % in [0.96, 1]
beta    = (1-ka)/(2*ka);
T       = 1000;                       % 1200, in [1000, 500, 100]
P       = 0.6;                        % in [0.6, 1, 2]
theta   = 7000;                       % 1143, in [1000, 2500, 5000, 7000]
tau_R   = 50;                         % in {20, 50}

% Analysis Parameters
num_itter       = 50;                   % <- CHANGES: resolution
param_num       = 1;                    % <- CHANGES: sys bif param
param_vals      = linspace(0, 0.15, num_itter);
h               = 1;
horizon         = 0.2e6;
transient       = 1e6;

% Evaluation Parameters
param_list = [eta, omega, alpha, beta, ka, T, P, theta, tau_R];
sim_past = [];

%% Simulation
disp('Simulation Started.')
tic

for itter = 1:num_itter
    %% Integrate
    param_list(param_num) = param_vals(itter);
    
    if ~isequal(transient, 0)
        sim_past = sim_laser_PCF_2(param_list, [h transient], sim_past, DIM);
    end
    
    if any(any(isnan(sim_past)))
        disp(['1. System has NaN values at itter = ', num2str(itter)])
        break
    end
    
    sim_past = sim_laser_PCF_2(param_list, [h horizon], sim_past, DIM);
    
    if any(any(isnan(sim_past)))
        disp(['2. System has NaN values at itter = ', num2str(itter)])
        break
    end
end

%% END MATLAB
disp('Simulation Completed')
toc
